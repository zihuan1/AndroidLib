package com.zihuan.app

object Constant {
    val BASE_URL = "baseurl"
    val API_KEY = "baseurl"
    // RSA 加密公钥
    val PUBLIC_KEY =""
    val NO_RSA = "NO_RSA"

}
