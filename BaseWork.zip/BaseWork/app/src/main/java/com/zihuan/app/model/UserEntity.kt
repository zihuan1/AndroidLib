package com.zihuan.app.model

/**
 */

class UserEntity {

    var id: Int = 0
    var uid: String? = null
    var token: String? = null
    var userName: String? = null
}
