package com.zihuan.app.base;

public interface BaseView  {
//    void showLoading();
//    void hideLoading();


}
